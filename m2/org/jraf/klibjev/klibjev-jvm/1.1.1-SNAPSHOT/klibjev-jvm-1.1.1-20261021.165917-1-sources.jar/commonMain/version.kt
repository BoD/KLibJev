// Generated file. Do not edit!
package org.jraf.klibjev
import kotlin.jvm.JvmField
@JvmField
val VERSION = "1.1.1-SNAPSHOT"
